from core.calculadora import Calculadora

# NOTA: Abir la actividad desde este directorio ./Actividad.5
# para ejecutarlo sin fallo de compilacion

class Main():

    def main():
        x = Calculadora()
    
    if __name__ == "__main__":
        main()