import startup as stup

class Main:

    def main():
        start_app = stup.Startup()

    if __name__ == "__main__":
        main()